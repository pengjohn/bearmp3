QuickTime Amp ver. 1.40

Why a QuickTime Winamp skin? 
----------------------------------
Well I love the way the new QuickTime 4.0 looks and the features of 
Winamp 2.0+ so, boom QuickTime Amp.


Creator :: Jose Perdomo
Email :: tekken3@bellsouth.net
Homepage :: http://www.perdomo-enterprises.com/xtreme

Thanks to EZoft for the helpful EZ Buttons v2.172 Freeware

QuickTime 4.0 is a registered trademark of Apple, Winamp is a 
trademark of Nullsoft, and Bill Gates is the anti-crist!