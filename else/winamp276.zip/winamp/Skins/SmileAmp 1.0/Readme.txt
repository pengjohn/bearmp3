Hola! �ste es mi primer skin. Espero que lo disfrutes y que te alegre un poco el d�a.
Para ocuparlo, puedes crear una carpeta Winamp\Skins\SmileAmp 1.0 y descomprimir ah� los archivos
o dejar este archivo .zip en tu carpeta Winamp\Skins\
Si algo del skin no te gusta, si�ntete libre de modificarlo (localmente!!), y notif�came
por favor a mi e-mail para mejorar las futuras versiones de SmileAmp.
Tambi�n puedes mandar sugerencias, comentarios, etc. (y claro: tus propios skins!)

Hi! This is my first skin. I hope you enjoy it and it cheers up your day a bit.
To use it, you may create a Winamp\Skins\SmileAmp 1.0 folder and unzip there the files
or either drop this .zip archive in your Winamp\Skins folder.
If you don't like any part of the skin, feel free to modify it (locally!!), and please notify me
to my e-mail so I can improve future versions of SmileAmp.
You can also send suggestions, comments, etc. (and of course: your own skins!)

Ariel Saavedra (War�n-chan)

�-------------------------------------------------�
|                                                 |
| SmileAmp 1.0 (c)1999 War�n-chan Santiago, Chile |
| waren@directo.cl                             =) |
|                                                 |
�-------------------------------------------------�