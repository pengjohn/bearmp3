**************************ALPHA AMP***************************
Thanx For Downing My New Skin...=)
Now that Winamp relesed 2.0 i feeled that i just have to do a "skin" to it.
and i think that it turn out to be pretty good. 
The ALPHA AMP is the re-placer for OMEGA AMP series but i think i will do 
one more OMEGA to Winamp 2.0 for my fans =).

******************My Skin So Far*************
Mr Hysch Amp
Hysch Amp II
Technics Amp
Omega Amp
Omega Amp II
Omega 2000
Mp3place Amp (Made this one for the guys at www.mp3place.com)
ALPHA AMP

Fell Free To Down This Other Skin From My HomePage.
http://home.sol.no/~siljab/amps.htm

********************Grettingz********************
I Wanna Thanx Mp3.com For The Great Site And Always Up to date page.
and For All The Stars I have Got.=) 

Layer3.org I wanna Thank U To For Not Rating My Suff AnyMore =(
And Others......That Is Boring. I No That U Guys Have Much To Do.

The Mp3 Place.....thank U For The Great Rating That you Have Giving Me.=) 

But The Biggest Thanx Goes To My Loving Girlfriend Who Has The Patience
And Understanding To Let ME Work With My Computer For Servral 
Hours A Day. And Not Spending My Time With Her..
I Love You Silja!!!!!.....=) U Should Have All The Stars.=)

************************Some Info************************
HomePage: http://home.sol.no/~siljab/amps.htm
E-Mail: mrhysch@home.se
ICQ: ******
