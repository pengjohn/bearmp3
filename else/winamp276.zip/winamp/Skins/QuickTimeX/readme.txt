QuickTime X skin for WINAMP 2.x
-------------------------------

Thanks for using this skin. I hope you'll find it useful.

This skin is based on QuickTime for the MacOs X. Enjoy !

if you have any comments or suggestions, contact me : stephane.feu@worldonline.fr

Have a look at my others skins : Blue Steel and NaWaK.


steph@ne - FRANCE